package com.booking.simpleBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
