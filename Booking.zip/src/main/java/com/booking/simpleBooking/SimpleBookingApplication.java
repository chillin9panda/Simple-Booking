package com.booking.simpleBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleBookingApplication.class, args);
	}

}
